'use strict';
try {
  var capture = window.capture
  var guide = window.guide
  var monitor = window.monitor
  try {
    guide.remove()
    capture.remove()
    monitor.remove()
  } catch(error) {}

  function createElement(tag, classe) {
    const element = document.createElement(tag)
    if (classe) {
      element.setAttribute('class', classe)
    }
    return element
  }
  class Capture {
    constructor() {
      this.mousedown = this.mousedown.bind(this)
      this.capture = this.capture.bind(this)
      this.update = this.update.bind(this)
      this.rect = {}
    }
    calc() {
      return {
        left: Math.min(this.rect.lt.x, this.rect.rb.x), top: Math.min(this.rect.lt.y, this.rect.rb.y),
        width: Math.abs(this.rect.rb.x - this.rect.lt.x), height: Math.abs(this.rect.rb.y - this.rect.lt.y)
      } 
    }
    update(event) {
      this.rect.rb.x = event.clientX
      this.rect.rb.y = event.clientY
      const calc = this.calc()
      for (const [key, value] of Object.entries(calc)) {
        this.box.style[key] = `${value}px`
      }
    }
    capture(event) {
      console.log('remove:',event)
      chrome.runtime.sendMessage({
        method: 'captured',
        calc: this.calc(),
        devicePixelRatio: window.devicePixelRatio,
        title: document.title,
        service: window.service
      })
      guide.remove()
      monitor.remove()
    }
    mousedown(event) {
      event.stopPropagation()
      event.preventDefault()
      this.box = createElement('div', 'itrisearch-box')
      this.rect.lt = {
        x: event.clientX,
        y: event.clientY
      }
      this.rect.rb = {
        x: event.clientX,
        y: event.clientY
      }
      
      document.addEventListener('mousemove', this.update)
      document.addEventListener('mouseup', this.capture)
      document.body.appendChild(this.box)
    }
    install() {
      document.addEventListener('mousedown', this.mousedown)
    }
    remove() {
      document.removeEventListener('mousedown', this.mousedown)
      document.removeEventListener('mousemove', this.update)
      document.removeEventListener('mouseup', this.capture)
      for (const element of [...document.querySelectorAll('.itrisearch-box')]) {
        element.remove()
      }
    }
  }
  class Guide {
    constructor() {
      this.update = this.update.bind(this)
    }
    position(left, top) {
      this.guide1.style.width = `${left}px`
      this.guide2.style.height = `${top}px`
    }
    update(event) {
      this.position(event.clientX, event.clientY)
    }
    install() {
      this.guide1 = createElement('div', 'itrisearch-guide-1')
      this.guide2 = createElement('div', 'itrisearch-guide-2')
      this.guide3 = createElement('div', 'itrisearch-guide-3')
      document.body.appendChild(this.guide3)
      document.body.appendChild(this.guide1)
      document.body.appendChild(this.guide2)
      document.addEventListener('mousemove', this.update, false)
    }
    remove() {
      document.removeEventListener('mousemove', this.update, false)
      for (const element of [...document.querySelectorAll('.itrisearch-guide-1, .itrisearch-guide-2, .itrisearch-guide-3')]) {
        element.remove();
      }
      capture.remove()
    }
  }
  class Monitor {
    constructor() {
      this.keydown = this.keydown.bind(this)
      this.install()
    }
    keydown(event) {
      if (event.code === 'Escape') {
        capture.remove()
        monitor.remove()
        guide.remove()
        chrome.runtime.sendMessage({
          method: 'aborted'
        })
      }
    }
    install() {
      document.addEventListener('keydown', this.keydown)
    }
    remove() {
      document.removeEventListener('keydown', this.keydown)
    }
  }

  capture = new Capture()
  monitor = new Monitor()
  guide = new Guide()

  capture.install()
  monitor.install()
  guide.install()

} catch(error) {}
