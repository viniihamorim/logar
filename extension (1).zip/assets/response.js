'use strict'
var div = window.div;

if (!div) {
  div = document.createElement('div')
  div.setAttribute('class', 'div-frame-group')
  document.body.appendChild(div);
}

chrome.runtime.onMessage.addListener((request) => {
  const method = request.method
  const methods = {
    'close-me': function() {
        if (div && request.all) {
            div.remove()
            div = null
        }
        const element = document.getElementById(request.id)
        if (element) {
            element.remove()
            if (div.children.length === 0) {
                div.style.display = 'none'
            }
        }
    }
  }
  const run = methods[method]
  if (run) {
    run()
  }
})

{
  const iframe = document.createElement('iframe');
  iframe.setAttribute('class', 'iframe-tesseract')
  const id = 'ocr-' + Math.random()
  iframe.id = id
  iframe.src = chrome.runtime.getURL('public/index.html?id=' + id + '&href=' + encodeURIComponent(location.href));
  div.style.display = 'flex';
  div.appendChild(iframe);
}
