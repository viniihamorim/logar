function notify(error) {
  return chrome.notifications.create({
    type: 'basic',
    iconUrl: 'public/icons/icon-128.png',
    title: 'Error',
    message: error.message ? error.message : error.toString()
  })
}
async function runScripts({id, script, css}) { 
  if (id) {
    if (css) {
      await chrome.scripting.insertCSS({
        target: {
          tabId: id
        },
        files: [css]
      })
    }
    if (script) {
      await chrome.scripting.executeScript({
        target: {
          tabId: id
        },
        files: [script]
      })
    }
  }
}
async function eventStart(command, tab) {
  try {
    const id = tab ? tab.id : command.id
    await runScripts({
      id: id,
      css: 'assets/inject.css',
      script: 'assets/inject.js'
    })
  } catch(error) {}
}
async function captureReturn(href, calc, devicePixelRatio) {
  cache[sender.tab.id] = {
    width: calc.width * devicePixelRatio,
    height: calc.height * devicePixelRatio,
    left: calc.left * devicePixelRatio,
    top: calc.top * devicePixelRatio,
    href
  }
  await runScripts({
    id: sender.tab.id,
    css: 'assets/response.css',
    script: 'assets/response.js'
  })
}
function onMessage(request, sender, response) {
  const methods = {
    'captured': function() {
      chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png'}, function(href) { 
        captureReturn(href, request.calc, request.devicePixelRatio)
      })
    },
    'image': function() {
      response(cache[sender.tab.id]);
      delete cache[sender.tab.id];
    },
    'close-me'  : function() {
      chrome.tabs.sendMessage(sender.tab.id, request)
    }
  }
  const run = methods[request.method]
  if (run) {
    run()
  } 
}
const cache = {}
chrome.commands.onCommand.addListener(eventStart)
chrome.action.onClicked.addListener(eventStart)
chrome.runtime.onMessage.addListener(onMessage)