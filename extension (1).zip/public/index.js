const args = new URLSearchParams(window.location.search)
function post(request, options) {
  chrome.runtime.sendMessage(request, options)
}
function logger(report) {
  if (report.status === 'recognizing text') {
    document.getElementById('recognize').value = report.progress
  }
}
async function coreRun(src) {
  const worker = Tesseract.createWorker({
    'workerBlobURL': false,
    'workerPath': '/core/worker.min.js',
    'corePath': '/core/tesseract-core.asm.js',
    logger: logger,
  })
  await worker.load()
  await worker.loadLanguage('por')
  await worker.initialize('por')
  await worker.setParameters({
    tessedit_pageseg_mode: Tesseract.PSM.SINGLE_BLOCK,
    tessedit_ocr_engine_mode: Tesseract.DEFAULT
  })
  const dados = (await worker.recognize(src))
  await worker.terminate()
  return dados.data
}
function imageSetting({width, height, left, top, href}) {
  const canvas = document.createElement('canvas')
  const ctx = canvas.getContext('2d')
  const img = new Image()
  img.src = href
  img.onload = () => {
    canvas.width = width || img.width
    canvas.height = height || img.height
    if (width && height) {
      ctx.drawImage(img, left, top, width, height, 0, 0, width, height)
    } else {
      ctx.drawImage(img, 0, 0)
    }
    run()
  }
  async function run() { 
    const result = document.getElementById('result')
    const src = canvas.toDataURL()
    document.getElementById('recognize').value = 0
    result.textContent = ''
    try {
      const dados = await coreRun(src)
      const texto = dados.text.replace(/\n/g, ' ')
      if (texto === '') {
        result.textContent = 'Nenhum texto encontrado'
      } else {
        result.textContent = texto
        document.getElementById('copy').disabled = false
      }
    } catch(error) {}
  }
}

post({method: 'image'}, imageSetting)

document.getElementById('copy').addEventListener('click', element => {
  const value = document.getElementById('result').innerText;
  navigator.clipboard.writeText(value)
    .then(() => {
      element.target.value = 'Feito';
      setTimeout(() => element.target.value = 'Copiar', 1000);
    })
    .catch(() => {
      const textArea = document.createElement('textarea');
      textArea.value = value;
      textArea.setAttribute('readonly', '');
      textArea.style.position = 'absolute';
      textArea.style.left = '-9999px';
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      element.target.value = 'Feito';
      setTimeout(() => element.target.value = 'Copiar', 1000);
    })
})
document.getElementById('close').addEventListener('click', function(event) {
  post({method: 'close-me', id: args.get('id'),  all: event.shiftKey})
})